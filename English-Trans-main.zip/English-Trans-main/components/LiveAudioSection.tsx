
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { LiveServerMessage } from '@google/genai';
import { getGeminiClient } from '../services/geminiService';
import { decode, encode, decodeAudioData } from '../utils/audioUtils';
import { TranscriptionMessage } from '../types';

const LiveAudioSection: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [transcripts, setTranscripts] = useState<TranscriptionMessage[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  
  const nextStartTimeRef = useRef(0);
  const audioContextInRef = useRef<AudioContext | null>(null);
  const audioContextOutRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const micStreamRef = useRef<MediaStream | null>(null);
  const currentOutputTranscriptionRef = useRef('');
  const currentInputTranscriptionRef = useRef('');

  const stopAllAudio = useCallback(() => {
    sourcesRef.current.forEach(source => {
      try { source.stop(); } catch (e) {}
    });
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
  }, []);

  const startSession = async () => {
    setIsConnecting(true);
    try {
      const ai = getGeminiClient();
      
      micStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioContextInRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextOutRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            console.log("Live session opened");
            setIsActive(true);
            setIsConnecting(false);

            // Setup mic streaming
            if (audioContextInRef.current && micStreamRef.current) {
              const source = audioContextInRef.current.createMediaStreamSource(micStreamRef.current);
              const processor = audioContextInRef.current.createScriptProcessor(4096, 1, 1);
              processor.onaudioprocess = (e) => {
                const inputData = e.inputBuffer.getChannelData(0);
                const l = inputData.length;
                const int16 = new Int16Array(l);
                for (let i = 0; i < l; i++) {
                  int16[i] = inputData[i] * 32768;
                }
                const pcmBlob = {
                  data: encode(new Uint8Array(int16.buffer)),
                  mimeType: 'audio/pcm;rate=16000',
                };
                sessionPromise.then((session) => {
                  session.sendRealtimeInput({ media: pcmBlob });
                });
              };
              source.connect(processor);
              processor.connect(audioContextInRef.current.destination);
            }
          },
          onmessage: async (message: LiveServerMessage) => {
            // Audio output
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && audioContextOutRef.current) {
              const ctx = audioContextOutRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            // Transcriptions
            if (message.serverContent?.inputTranscription) {
              currentInputTranscriptionRef.current += message.serverContent.inputTranscription.text;
            }
            if (message.serverContent?.outputTranscription) {
              currentOutputTranscriptionRef.current += message.serverContent.outputTranscription.text;
            }

            if (message.serverContent?.turnComplete) {
              if (currentInputTranscriptionRef.current) {
                setTranscripts(prev => [...prev, { 
                  role: 'user', 
                  text: currentInputTranscriptionRef.current, 
                  timestamp: Date.now() 
                }]);
                currentInputTranscriptionRef.current = '';
              }
              if (currentOutputTranscriptionRef.current) {
                setTranscripts(prev => [...prev, { 
                  role: 'model', 
                  text: currentOutputTranscriptionRef.current, 
                  timestamp: Date.now() 
                }]);
                currentOutputTranscriptionRef.current = '';
              }
            }

            if (message.serverContent?.interrupted) {
              stopAllAudio();
            }
          },
          onerror: (e) => {
            console.error("Live Error:", e);
            stopSession();
          },
          onclose: () => {
            console.log("Live session closed");
            stopSession();
          }
        },
        config: {
          responseModalities: ['AUDIO'],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          },
          systemInstruction: 'You are a helpful English conversation partner. Speak naturally and clearly. Correct the user politely if they make mistakes.'
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (error) {
      console.error("Failed to start session:", error);
      setIsConnecting(false);
      alert("Mic access is required for conversation mode.");
    }
  };

  const stopSession = () => {
    setIsActive(false);
    setIsConnecting(false);
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(t => t.stop());
      micStreamRef.current = null;
    }
    stopAllAudio();
  };

  useEffect(() => {
    return () => stopSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      <div className="glass-card p-8 rounded-3xl shadow-2xl">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <i className="fa-solid fa-comments text-purple-400"></i>
            Conversational Partner
          </h2>
          <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold ${isActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700 text-slate-400'}`}>
            <span className={`w-2 h-2 rounded-full ${isActive ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'}`}></span>
            {isActive ? 'LIVE' : 'OFFLINE'}
          </div>
        </div>

        <div className="h-80 overflow-y-auto mb-6 space-y-4 pr-2 custom-scrollbar">
          {transcripts.length === 0 && !isActive && !isConnecting && (
            <div className="h-full flex flex-col items-center justify-center text-slate-500 text-center px-8">
              <i className="fa-solid fa-headset text-4xl mb-4 opacity-20"></i>
              <p>Start a conversation to practice your English speaking skills with AI.</p>
            </div>
          )}
          {transcripts.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] p-4 rounded-2xl ${
                msg.role === 'user' 
                  ? 'bg-blue-600/20 text-blue-100 border border-blue-500/30' 
                  : 'bg-slate-800 text-slate-200 border border-slate-700'
              }`}>
                <p className="text-sm leading-relaxed">{msg.text}</p>
              </div>
            </div>
          ))}
          {isConnecting && (
            <div className="flex justify-start">
              <div className="bg-slate-800 p-4 rounded-2xl animate-pulse text-slate-400 text-sm">
                Initializing voice context...
              </div>
            </div>
          )}
        </div>

        <button
          onClick={isActive ? stopSession : startSession}
          disabled={isConnecting}
          className={`w-full py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-3 shadow-lg ${
            isActive 
              ? 'bg-red-500 hover:bg-red-600 text-white shadow-red-500/20' 
              : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-indigo-500/20'
          }`}
        >
          {isConnecting ? (
            <i className="fa-solid fa-circle-notch animate-spin"></i>
          ) : (
            <i className={`fa-solid ${isActive ? 'fa-phone-slash' : 'fa-phone'}`}></i>
          )}
          {isConnecting ? 'Establishing Connection...' : isActive ? 'End Conversation' : 'Start English Session'}
        </button>
      </div>
    </div>
  );
};

export default LiveAudioSection;
