
import React, { useState, useRef } from 'react';
import { generateTTS, getWordMetadata } from '../services/geminiService';
import { pcmToWav, decodeAudioData } from '../utils/audioUtils';
import { HistoryItem, VoiceOption } from '../types';

const TTSSection: React.FC = () => {
  const [text, setText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<VoiceOption>('Kore'); // Kore: Female, Puck: Male
  const audioContextRef = useRef<AudioContext | null>(null);

  const handleGenerate = async () => {
    if (!text.trim()) return;
    setIsGenerating(true);
    try {
      const sampleRate = 24000;
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate });
      }

      // Parallel requests for speed: Metadata (IPA/Translation) and Audio
      const [metadata, pcmData] = await Promise.all([
        getWordMetadata(text),
        generateTTS(text, selectedVoice)
      ]);

      const buffer = await decodeAudioData(pcmData, audioContextRef.current, sampleRate, 1);
      const wavBlob = pcmToWav(pcmData, sampleRate);

      const newItem: HistoryItem = {
        id: Date.now().toString(),
        text: text.trim(),
        ipa: metadata.ipa,
        translation: metadata.translation,
        audioBlob: wavBlob,
        audioBuffer: buffer,
        timestamp: Date.now(),
        voice: selectedVoice
      };

      setHistory(prev => [newItem, ...prev]);
      playAudio(buffer);
      setText(''); // Clear input for next word
    } catch (error) {
      console.error("TTS Generation Error:", error);
      alert("Failed to process request. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const playAudio = (buffer: AudioBuffer) => {
    if (!audioContextRef.current) return;
    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    source.start();
  };

  const handleDownload = (item: HistoryItem) => {
    const url = URL.createObjectURL(item.audioBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${item.text.slice(0, 10).replace(/\s+/g, '_')}_${item.voice}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-8">
      {/* Input Section */}
      <div className="glass-card p-8 rounded-3xl shadow-2xl transition-all duration-300 hover:shadow-blue-500/10">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <i className="fa-solid fa-microphone-lines text-blue-400"></i>
            English Pronunciation
          </h2>
          
          {/* Voice Switcher */}
          <div className="flex bg-slate-800 p-1 rounded-lg border border-slate-700">
            <button
              onClick={() => setSelectedVoice('Kore')}
              className={`px-3 py-1 rounded text-xs font-bold transition-all ${
                selectedVoice === 'Kore' ? 'bg-pink-600 text-white' : 'text-slate-400'
              }`}
            >
              <i className="fa-solid fa-venus mr-1"></i> Female
            </button>
            <button
              onClick={() => setSelectedVoice('Puck')}
              className={`px-3 py-1 rounded text-xs font-bold transition-all ${
                selectedVoice === 'Puck' ? 'bg-blue-600 text-white' : 'text-slate-400'
              }`}
            >
              <i className="fa-solid fa-mars mr-1"></i> Male
            </button>
          </div>
        </div>
        
        <div className="relative mb-6">
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleGenerate();
              }
            }}
            placeholder="Enter word or sentence (e.g., 'Phenomenon')"
            className="w-full bg-slate-800/50 border border-slate-700 rounded-2xl p-4 text-lg focus:ring-2 focus:ring-blue-500 outline-none min-h-[100px] transition-all"
          />
        </div>

        <button
          onClick={handleGenerate}
          disabled={isGenerating || !text.trim()}
          className={`w-full flex items-center justify-center gap-2 py-4 rounded-xl font-semibold transition-all ${
            isGenerating 
              ? 'bg-slate-700 cursor-not-allowed text-slate-400' 
              : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/20 active:scale-95'
          }`}
        >
          {isGenerating ? (
            <i className="fa-solid fa-circle-notch animate-spin"></i>
          ) : (
            <i className="fa-solid fa-wand-magic-sparkles"></i>
          )}
          {isGenerating ? 'Processing...' : 'Generate Voice & IPA'}
        </button>
      </div>

      {/* History Section */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-400 flex items-center gap-2 px-2">
          <i className="fa-solid fa-clock-rotate-left text-sm"></i>
          History
        </h3>
        
        {history.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed border-slate-800 rounded-3xl">
            <p className="text-slate-600">No entries yet. Start by typing something above!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {history.map((item) => (
              <div key={item.id} className="glass-card p-5 rounded-2xl border-l-4 border-l-blue-500 animate-in slide-in-from-top duration-300">
                <div className="flex justify-between items-start gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <span className="text-xl font-bold text-white">{item.text}</span>
                      <span className="text-blue-400 font-mono text-sm bg-blue-500/10 px-2 py-0.5 rounded">{item.ipa}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-400">
                      <i className="fa-solid fa-language text-xs"></i>
                      <p className="text-sm italic">{item.translation}</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={() => playAudio(item.audioBuffer)}
                      className="w-10 h-10 flex items-center justify-center bg-slate-700 hover:bg-slate-600 rounded-full transition-colors text-blue-400"
                      title="Play"
                    >
                      <i className="fa-solid fa-play"></i>
                    </button>
                    <button
                      onClick={() => handleDownload(item)}
                      className="w-10 h-10 flex items-center justify-center bg-slate-700 hover:bg-slate-600 rounded-full transition-colors text-emerald-400"
                      title="Download"
                    >
                      <i className="fa-solid fa-download"></i>
                    </button>
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-3 text-[10px] uppercase tracking-wider text-slate-600 font-bold border-t border-slate-800/50 pt-2">
                  <span>Voice: {item.voice === 'Kore' ? 'Female' : 'Male'}</span>
                  <span>•</span>
                  <span>{new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="text-center text-slate-500 text-xs py-4">
        Each entry uses Gemini reasoning for IPA and Translation.
      </div>
    </div>
  );
};

export default TTSSection;
