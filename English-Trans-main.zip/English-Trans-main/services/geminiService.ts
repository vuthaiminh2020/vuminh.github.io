
import { GoogleGenAI, Type } from "@google/genai";
import { decode } from "../utils/audioUtils";

const API_KEY = process.env.API_KEY || "";

export const getGeminiClient = () => {
  return new GoogleGenAI({ apiKey: API_KEY });
};

/**
 * Fetches IPA and Vietnamese translation for a given English text.
 */
export const getWordMetadata = async (text: string) => {
  const ai = getGeminiClient();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [{ 
      parts: [{ 
        text: `Analyze this English text: "${text}". Provide the IPA (International Phonetic Alphabet) transcription and the Vietnamese translation.` 
      }] 
    }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          ipa: { type: Type.STRING, description: "The IPA transcription of the text" },
          translation: { type: Type.STRING, description: "The Vietnamese translation of the text" }
        },
        required: ["ipa", "translation"]
      }
    }
  });

  try {
    return JSON.parse(response.text || '{}');
  } catch (e) {
    console.error("Failed to parse metadata", e);
    return { ipa: "/.../", translation: "N/A" };
  }
};

/**
 * Generates TTS audio. 
 * Note: gemini-2.5-flash-preview-tts requires the contents to be an array 
 * and is highly sensitive to the prompt format.
 */
export const generateTTS = async (text: string, voiceName: string) => {
  const ai = getGeminiClient();
  
  // Prepending a simple instruction often prevents 500 Internal Errors 
  // by giving the model a clear context for audio generation.
  const ttsPrompt = `Speak this text clearly: ${text}`;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ 
      parts: [{ text: ttsPrompt }] 
    }],
    config: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName },
        },
      },
    },
  });

  // Safe navigation for candidates and parts
  const candidate = response.candidates?.[0];
  const audioPart = candidate?.content?.parts?.find(part => part.inlineData);
  const base64Audio = audioPart?.inlineData?.data;

  if (!base64Audio) {
    console.error("Full Response Trace:", response);
    throw new Error("No audio data returned in the response parts.");
  }
  
  return decode(base64Audio);
};
